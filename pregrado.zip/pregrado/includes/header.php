<!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PGQ6BCP"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
  <header class="home-area" id="home_page">
<header class="py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 col-6">

                    <img src="assets/img/logo-ucv.svg" alt="" class="img-fluid img-desk">
                    <img src="assets/img/icon-ucv.svg" alt="" class="img-fluid img-mobile">

                </div>
                <div class="col-md-6 col-6">
                    <div class="btn-box">
                        <img src="assets/img/logo-licenciada.svg?v=2" alt="" class="img-fluid">

                    </div>


                </div>

            </div>

        </div>
    </header>