<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="icon" href="../img/favicon.png" type="image/png">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>UCV - Dirección de Relaciones Internacionales</title>
    <style>
        @font-face {
            font-family: "Prelo Exbd";
            src: url(fonts/PreloSlab-ExBd.otf);
        }

        @font-face {
            font-family: "PreloSlab Bold";
            src: url(fonts/PreloSlab-Bold.otf);
        }

        @font-face {
            font-family: "PreloSlab Book";
            src: url(fonts/PreloSlab-Book.otf);
        }

        @font-face {
            font-family: "PreloSlab Medium";
            src: url(fonts/PreloSlab-Medium.otf);
        }

        @font-face {
            font-family: "PreloSlab Semi";
            src: url(fonts/PreloSlab-SemiBold.otf);
        }

        body {
            font-family: "PreloSlab Medium";
        }

        h1 {
            font-family: "Prelo Exbd";
        }

        .title-banner {
            color: #2D3858;
            font-family: "Prelo Exbd";
            font-size: 55px;
        }
.text-r{
    text-align: right;
}
        .subtitle {
            color: #2D3858;
            font-family: "PreloSlab Book";
        }

        .subtitle-two {
            font-size:20px;
            color: #2D3858;
        }

        .l-container {
            padding: 50px 0;
            padding-top: 25px;
        }

        .lista-beneficios h4 {
            color: #C10F19;
            font-family: "Prelo Exbd";
        }

        .lista-beneficios ul {
            padding-left: 0;
        }

        .lista-beneficios li {
            font-size:15px;
            list-style: none;
            color: #2D3858;
            margin-bottom: 5px;
            font-family: "PreloSlab Semi";

        }
.icon-ucv{
    float: right;
}
        #contenido-ucv {
            background-color: #EEECE6;
        }
        footer{
            padding: 30px 0;
            background-color: #EEECE6;
        }
        footer span{
            color: #2D3858;
            font-size: 13px;
        }
        .wrapper{
            background-image: url(img/fondo2.png);
            background-size: cover;
            height: 700px;
            background-position-x: center;
            margin-top: 90px;

    }
    header{
        background-color: #EEECE6;
    }
        #form-banner{
            padding: 45px 39px;
    padding-left: 25px;
    margin-top: 25px;
        }
        .title-form{
            color: white;
            line-height: 30px;
            font-family: "Prelo Exbd";

        }
        .form-group {
    margin-bottom: .5rem;
}
.wrapper-mobile{
    display: none;
}
.form-control {

    height: calc(1em + .75rem + 2px);
    }
    .bg-blue-ucv {
    background: #2D3858;
}
.poli{
    font-size: 11px;
    color: white;
}
.btn-enviar{
    background-color: #C10F19;
    border-color: #C10F19;
    padding: .375rem 1.75rem;
}
        @media (min-width: 1200px) {

            .container,
            .container-lg,
            .container-md,
            .container-sm,
            .container-xl {
                max-width: 1100px;
            }
        }
        @media (max-width: 991px) {
            footer{
                text-align: center!important;
                padding: 15px 0;
            }
            .text-r{
                text-align: center!important;

            }
.wrapper
{
    margin-top: 30px;
}
        }
        @media (max-width: 767px) {
            .poli{
                color: #606060;
            }
            .wrapper-mobile{
    display: block;
}
            .two-img{
                margin-top: 20px;
            }
            ::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
                color: white!important;
  opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
    color: white!important;
}

::-ms-input-placeholder { /* Microsoft Edge */
    color: white!important;
}
            .form-control {
background-color: #606060;
color: white;
height: calc(1em + .75rem + 5px);
            }
            .wrapper{
                height: auto;
            }
            .title-form{
                display: none;
            }
            #form-banner{
                padding: 0 20px;
                margin: 0;
                margin-top: -70px;
            }
            .abso{
                position: absolute;
    top: 25%;
    justify-content: flex-start;
    width: 100%;
    font-family: "Prelo Exbd";
            }
            .wrapper{
                background-image: none;
            }

        }
        @media (max-width: 360px) {
.title-mobile{
    font-size: 1.4rem;
}
        }
       
    </style>
    
    <!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-PGQ6BCP');</script>
	<!-- End Google Tag Manager -->
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PGQ6BCP"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
    <header class="pt-md-5 pt-3">
        <div class="container">
            <div class="row justify-content-end">
                <div class="col-lg-1 col-2">
                    <img src="img/icon-ucv.png" alt="" class="img-fluid icon-ucv">
                </div>
            </div>
        </div>
    </header>
    <main>
        <section id="contenido-ucv" class="l-container">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <h1 class="title-banner">UCV GO</h1>
                        <h6 class="subtitle mb-4">Disfruta la oportunidad de ampliar tus horizontes y vivir una
                            experiencia globalizada que te ayudará a desarrollar tu futuro. </h6>

                        <img src="img/icon-mundito.png" class="img-fluid" alt="">
                        <h4 class="subtitle-two mt-3">Emprende un nuevo futuro conociendo el mundo.<br>Postula a la Universidad Católica del Oriente de Colombia.
                        <br><br><strong>Cierre de inscripciones: 10 de enero</strong></h4>
                        <div class="lista-beneficios mt-5">
                            <h4>Beneficios para estudiantes*</h4>
                            <ul>
                                <li>
                                    - Estudia desde la comodidad de tu casa.
                                </li>
                                <li>
                                    - Agrégale un plus internacional a tu hoja de vida. </li>
                                <li>
                                    - Amplía tu networking. </li>
                                <li>
                                    - Obtén una experiencia intercultural. </li>
                                <li>
                                    - Participa en proyectos internacionales de investigación. </li>
                                <li>
                                    - Practica un nuevo idioma. </li>
                            </ul>
                        </div>
                        <p class="pt-md-5 mt-5" style="color: #2D3858; font-family: 'PreloSlab Semi';">*Estudiante deben tener ponderado 15.</p>

                    </div>
                    <div class="col-lg-8">
                        <div class="wrapper">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="wrapper-mobile">
                                        <img src="img/fondo2.png" alt="" class="img-fluid">
                                        <div class="row abso">
                                            <div class="col-5"></div>
                                            <div class="col-7">
                                                <h4 class="text-white title-mobile">¡Es tiempo de <br>maximizar tu mundo!</h4>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7" >
                                   <?php
                                        $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                                        $parts = parse_url($url);
                                        parse_str($parts['query'], $query);
                                        $sede = $query['sede'];
                                        $fbclid = $query['fbclid'];
                                        $gclid = $query['gclid'];
                                        $source = $query['source'];
                                        if(empty($source)){
                                            if(empty($fbclid)){
                                                if(empty($gclid)){
                                                    $source = "organico";
                                                }else{
                                                    $source = "google";
                                                }
                                            }else{
                                                $source = "facebook";
                                            }
                                        }else{
                                            $source=$source;
                                        }
                                    ?>
                                    <form id="form-banner" action="enviar.php" method="post">
                                        <h3 class="title-form">¡Es tiempo de <br>maximizar tu mundo!</h3>
                                        <div class="form-group">
                                          <input type="text" class="form-control" placeholder="DNI" name="dni" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Nombres" name="nombres" required>
                                          </div>
                                          <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Apellidos" name="apellidos" required>
                                          </div>
                                          <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Correo electrónico" name="email" required>
                                          </div>
                                          <div class="form-group">
                                            <input type="text" class="form-control"  placeholder="Celular" name="celular" required>
                                          </div>
                                          <div class="form-group">
                                            <select class="form-control" id="campus" name="campus" required>
                                              <option value="" selected disabled hidden>Selecciona tu campus</option>
                                              <option value="Ate">Ate</option>
                                              <option value="Callao">Callao</option>
                                              <option value="Chepén">Chepén</option>
                                              <option value="Chiclayo">Chiclayo</option>
                                              <option value="Chimbote">Chimbote</option>
                                              <option value="Huaraz">Huaraz</option>
                                              <option value="Los Olivos">Los Olivos</option>
                                              <option value="Moyobamba">Moyobamba</option>
                                              <option value="Piura">Piura</option>
                                              <option value="San Juan de Lurigancho">San Juan de Lurigancho</option>
                                              <option value="Tarapoto">Tarapoto</option>
                                              <option value="Trujillo">Trujillo</option>
                                            </select>
                                          </div>
                                          <input type="hidden" name="landing" value="DRI - Alumnos">
                                          <input type="hidden" name="source" value="<?php echo $source;?>" />
                                          <input type="hidden" name="url" value="<?php echo $url;?>" />
                                          <div class="form-group  form-check">
                                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                            <label class="form-check-label poli" for="exampleCheck1">Para poder informarte, autorízanos tus datos y a contactarte, según términos que puede revisar este <a href="https://trilce.ucv.edu.pe/politicas/PoliticaPrivacidad.html">enlace </a></label>
                                          </div>
                                          <div class="form-group mb-0">
                                            <button class="btn btn-danger btn-enviar" type="submit">Enviar</button>
                                          </div>
                                         
                                     </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer class="bg-blue-ucv">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-md-4 ">
                    <img src="img/logo-footer-one.svg" class="img-fluid d-block mx-auto logo-educa" alt="">
                </div>
                <div class="col-md-4 col-10">
                    <img src="img/logo-footer-two.svg" class="img-fluid  d-block mx-auto two-img" alt="">
                </div>
                <div class="col-md-8 pt-4">
                    <p class="text-center text-white mb-0">© 2020 Todos los derechos reservados - Universidad César Vallejo
                       </p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>


</body>

</html>