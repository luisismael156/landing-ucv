<?php


$colegio=$_POST['colegio'];
$departamento=$_POST['idDepa'];
$provincia=$_POST['idProv'];
$distrito=$_POST['ciudad_id'];
$nombres=$_POST['nombres'];
$apellidos=$_POST['apellidos'];
$telefono=$_POST['telefono'];
$correo=$_POST['correo'];
$sede=$_POST['sede'];
$evento=$_POST['evento'];
$source=$_POST['source'];
$dni=$_POST['dni'];
$cargo=$_POST['cargo'];



$condiciones = "Acepto";
$fecha=$_POST['fecha'];
$hora=$_POST['hora'];

$fecha=date('d-m-Y',strtotime($fecha));
$hora=date('h:i:s', time());

$servername = "localhost";
$username = "somosucvedu_eduexperience";
$password = "?[R,-2yP10{b";
$dbname = "somosucvedu_eduevento";

$database = "somosucvedu_ubigeo";
$consulta = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
//$consulta->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//$depa = $consulta->query("select name from ubdepartamento where id='$departamento'");
//$r=$depa->fetch(PDO::FETCH_ASSOC);
//$depafinal=$r[0];





//$deparesult = $conn->query($depa);
//foreach ($deparesult as $row) {
//    $depafinal = '' . $row['name'] ;
//}
//return $depafinal;
//$conn = null;


function getSingleValue($conn, $sql, $parameters)
{
    $q = $conn->prepare($sql);
    $q->execute($parameters);
    return $q->fetchColumn();
}

$depafinal = getSingleValue($consulta, "select name from ubdepartamento where id=?", [$departamento]); 
$provifinal = getSingleValue($consulta, "select name from ubprovincia where id=?", [$provincia]);
$distrifinal = getSingleValue($consulta, "select name from ubdistrito where id=?", [$distrito]); 
    
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    

    
    $condni = "select * from eduevento where dni='$dni'";
    $resultado = $conn->query($condni);
    if ($resultado->fetchColumn() > 0) {
        
        echo '<script type="text/javascript">alert("Usted ya se encuentra registrado. Gracias por su interes.");</script>';
        $url = "<meta http-equiv='refresh' content='1;URL=https://somosucv.edu.pe/'>";
        echo $url;
        
        
    }else{

        $sql = "INSERT INTO `eduevento` (`dni`,`nombreie`, `departamento`,`provincia`,`distrito`, `nombres`, `apellidos`, `cargo`, `telefono`, `correo`, `sede`, `condiciones`, `evento`, `source`, `fecha`) VALUES ('".$dni."','".$colegio."','".$depafinal."','".$provifinal."','".$distrifinal."','".$nombres."','".$apellidos."','".$cargo."','".$telefono."','".$correo."','".$sede."','".$condiciones."','".$evento."','".$source."',now())";
        $conn->exec($sql);

        echo '<script type="text/javascript">alert("Gracias por su registro. Nos contactaremos pronto.");</script>';
        $url = "<meta http-equiv='refresh' content='1;URL=https://somosucv.edu.pe/'>";
        echo $url;
        
    }

    
    
} catch(PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
}

$conn = null;

?>