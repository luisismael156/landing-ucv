<?php
// simple conexion a la base de datos
function connect(){
	return new mysqli("localhost","somosucvedu_eduexperience","?[R,-2yP10{b","somosucvedu_ubigeo");
}

?>